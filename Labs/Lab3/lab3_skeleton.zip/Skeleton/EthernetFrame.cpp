//
// EthernetFrame.cpp
//

#include "EthernetFrame.h"

// TODO: task 1: initialize & swap EthernetFrame

void initFrame(EthernetFrame &frame, const string &source, const string &destination,
               const string &payload, EtherType type) {
    return;
}

void initFrame(EthernetFrame *frame, const string &source, const string &destination,
               const string &payload, EtherType type) {
    return;
}

void swapFrames(EthernetFrame &frame1, EthernetFrame &frame2) {
    return;
}

void swapFrames(EthernetFrame *frame1, EthernetFrame *frame2) {
    return;
}

// TODO: task 2: create & free EthernetFrame

EthernetFrame *createFrame(const string &source, const string &destination, const string &payload, EtherType type) {
    return nullptr;
}

void freeFrame(EthernetFrame *frame) {
    return;
}
