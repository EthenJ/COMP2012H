//
// Queue.cpp
//

#include "Queue.h"
#include "EthernetFrame.h"

// TODO: task 3: queue operations

void queueResizeRing(Queue &queue, unsigned int newCapacity) {
    return;
}

void enqueue(Queue &queue, EthernetFrame *frame) {
    return;
}

void dequeue(Queue &queue) {
    return;
}

const EthernetFrame *queueFront(const Queue &queue) {
    return nullptr;
}

const EthernetFrame *queueBack(const Queue &queue) {
    return nullptr;
}

bool queueIsEmpty(const Queue &queue) {
    return true;
}

void freeQueue(Queue &queue) {
    return;
}
